package operations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class BrowserInitialization {
	static WebDriver driver;

    public static WebDriver StartBrowser(String URL)
    {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(URL);
		return driver;
 
	}

}
