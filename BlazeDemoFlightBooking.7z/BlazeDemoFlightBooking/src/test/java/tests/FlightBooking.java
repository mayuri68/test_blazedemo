package tests;

import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;

import objectrepo.HomePage;
import objectrepo.SelectFlight;
import operations.BrowserInitialization;
import operations.ScreenShots;


public class FlightBooking {
	WebDriver driver;
	SelectFlight sf;
	HomePage hp;
	int i = 0;
	
	@Parameters({"URL"})
	@BeforeTest
	 public void browserlaunch(String URL)
     {
                    driver = BrowserInitialization.StartBrowser(URL);
                    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
                    hp = new HomePage(driver);
                    sf = new SelectFlight(driver);
     }
                    
	

	@Parameters({"departureCity","arrivalCity"})
	@Test(priority=1)
	public void selectDestinations(String departureCity,String arrivalCity)
	{
		hp.MakeSelections(departureCity, arrivalCity);
	}
	
	@Parameters({"departureCity","arrivalCity"})
	@Test(priority=2)
	public void reserveFlight(String departureCity,String arrivalCity) 
	{
		//Verify if we landed on Flight Selection page
		Assert.assertEquals(sf.getHeading(), "Flights from Paris to Rome:");
		
		//Verify if departure city is as per selection
		Assert.assertEquals(sf.getDeparts(), "Departs: "+departureCity);
		
		//Verify if arrival city is as per selection
		Assert.assertEquals(sf.getArrives(), "Arrives: "+arrivalCity);
		
		//Choose one of the flights
		sf.flightSelection();	
		
		//Verify if navigation is done to flight purchase page
		Assert.assertEquals(driver.getCurrentUrl(), "https://blazedemo.com/purchase.php");
	}
	
	// Taking Screen shot on test fail
    @AfterMethod
    public void screenshot(ITestResult result)
    {
               i = i+1;
               String name = "ScreenShot";
               String x = name+String.valueOf(i);
              if(ITestResult.FAILURE == result.getStatus())
                {
                               ScreenShots.captureScreenShot(driver, x);
                 }
}
	
	@AfterTest
	public void closeBrowser() 
	{
        driver.quit();
	}

}
